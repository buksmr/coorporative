<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>
<script>
import bulma from "bulma-extensions";
export default {
  components: {
    bulma
  }
};
</script>


