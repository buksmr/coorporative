<template>
  <div class="hero-foot foot-bg-color">
    <div class="container is-fluid">
      <div class="has-text-centered">
        <ul>
          <li>
            <a
              class="has-text-white-bis is-size-7"
            >© {{new Date().getFullYear()}} Copyright: Bluewaves</a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>