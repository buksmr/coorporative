<?php

namespace App\Models;



class Product extends UuidModel
{
    //
}
