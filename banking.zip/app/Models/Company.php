<?php

namespace App\Models;

class Company extends UuidModel
{
	
}
