<?php

namespace App\Models;



class productmap extends UuidModel
{
    //
}
