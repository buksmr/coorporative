<?php

namespace App\Models;



class TaxRate extends UuidModel
{
    //
}
