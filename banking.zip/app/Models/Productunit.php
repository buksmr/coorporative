<?php

namespace App\Models;



class ProductUnit extends UuidModel
{
    //
}
